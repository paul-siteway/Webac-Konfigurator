https://www.youtube.com/watch?v=qWr7x9wk6_c&list=PL5_haDJv_VCZE0kGybmIW_Zc-a9foeBzJ

https://www.youtube.com/watch?v=qWr7x9wk6_c

https://www.youtube.com/watch?v=hBVYDVy3QNI
https://www.youtube.com/watch?v=M-8THMnC_wY

https://www.youtube.com/watch?v=0o2whtCJw8I&list=PLVptK_YARe4vFWHRZxj4dwC6r03i49qiO

http://lostechies.com/derickbailey/2013/02/11/marionettejs-screencasts-and-videos/

http://vimeo.com/59431658

http://www.funnyant.com/backbone-and-marionette-derick-bailey/