MAPAPP
======







A single page application for displaying and filtering locations  on a google map.

# This project is using: 

frontend toolkit:
- [twitter boostrap] (http://twitter.github.com/bootstrap/)
- [bootstrap-multiselect] (https://github.com/davidstutz/bootstrap-multiselect)

javascript mvc framework:
- [backbone.js] (http://backbonejs.org/)
- [backbone query] (https://github.com/davidgtonge/backbone_query)

mapping:
- [gmaps.js] (http://hpneo.github.com/gmaps/) 
- [google maps api] (https://developers.google.com/maps/?hl=de)


TODO: 

- [x] Create Subviews for each Anwendungsgebiet
- [ ] Hook up onselectChage Events and rebuild query object
